<?php
echo '<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#">ACME Arts</a>
    </div>
    <ul class="nav navbar-nav">
      <li class="active"><a href="index.php">Index</a></li>
      <li class="dropdown">
        <a class="dropdown-toggle" data-toggle="dropdown" href="#">Artists
        <span class="caret"></span></a>
        <ul class="dropdown-menu">
		  <li><a href="renoir.php">Renoir</a></li>
		  <li><a href="michelangelo.php">Michelangelo</a></li>
		  <li><a href="vangogh.php">Van Gogh</a></li>
		  <li><a href="davinci.php">da Vinci</a></li>
		  <li><a href="monet.php">Monet</a></li>
		  <li><a href="picasso.php">Picasso</a></li>
		  <li><a href="dali.php">Dali</a></li>
		  <li><a href="cezanne.php">Cezanne</a></li>
        </ul>
      </li><li class="dropdown">
        <a class="dropdown-toggle" data-toggle="dropdown" href="#">Styles
        <span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="impressionism.php">Impressionism</a></li>		  
          <li><a href="mannerism.php">Mannerism</a></li>		  
          <li><a href="still-life.php">Still-Life</a></li>		  
          <li><a href="portrait.php">Portrait</a></li>
          <li><a href="realism.php">Realism</a></li>
          <li><a href="cubism.php">Cubism</a></li>
		  <li><a href="surrealism.php">Surrealism</a></li>
        </ul>
      </li>
    </ul>
    </li>
    </ul>
    <form class="navbar-form navbar-left" action="search.php">
      <div class="form-group">
        <input 
          type="search" 
          id="mysearch"
          name="q"
          placeholder="Search"
          />
      </div>
      <button type="submit" class="btn btn-default">Submit</button>
    </form>
  </div>
</nav>';
?>